use std::{
    future::{Future, IntoFuture},
    io,
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

use axum::{Json, Router, extract::State, http::StatusCode, routing::get};
use serde::Serialize;
use tokio::{net::TcpListener, sync::oneshot};

#[derive(Clone, Default)]
pub struct GatewayLifecycleState {
    ready: Arc<AtomicBool>,
    disabled: bool,
    drain_deadline: Arc<Mutex<Option<tokio::time::Instant>>>,
}

impl GatewayLifecycleState {
    /// Deadline shared by connection draining and telemetry delivery.
    ///
    /// # Panics
    /// Panics if the lifecycle lock was poisoned.
    pub fn drain_deadline(&self) -> Option<tokio::time::Instant> {
        *self
            .drain_deadline
            .lock()
            .expect("gateway drain lock poisoned")
    }

    pub fn is_ready(&self) -> bool {
        !self.disabled && self.ready.load(Ordering::Acquire)
    }

    /// Keep liveness available without advertising inference readiness.
    pub fn unconfigured() -> Self {
        Self {
            disabled: true,
            ..Self::default()
        }
    }
}

#[derive(Serialize)]
struct Probe {
    status: &'static str,
}

pub fn router(state: GatewayLifecycleState) -> Router {
    Router::new()
        .route("/health", get(|| async { Json(Probe { status: "ok" }) }))
        .route("/ready", get(readiness))
        .with_state(state)
}

async fn readiness(State(state): State<GatewayLifecycleState>) -> (StatusCode, Json<Probe>) {
    if state.is_ready() {
        (StatusCode::OK, Json(Probe { status: "ready" }))
    } else {
        (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(Probe {
                status: if state.disabled {
                    "unconfigured"
                } else {
                    "draining"
                },
            }),
        )
    }
}

/// Serve an initialized router until shutdown, then bound connection draining.
/// A timeout must terminate the owning process/runtime to stop remaining tasks.
///
/// # Errors
/// Returns the server's I/O error, or [`io::ErrorKind::TimedOut`] if connections
/// do not finish draining within `shutdown_timeout`.
///
/// # Panics
/// Panics if the lifecycle lock was poisoned.
pub async fn serve(
    listener: TcpListener,
    app: Router,
    state: GatewayLifecycleState,
    shutdown: impl Future<Output = ()> + Send + 'static,
    shutdown_timeout: Duration,
) -> io::Result<()> {
    let (draining_tx, draining_rx) = oneshot::channel();
    let shutdown_state = state.clone();
    let server = axum::serve(listener, app)
        .with_graceful_shutdown(async move {
            shutdown.await;
            shutdown_state.ready.store(false, Ordering::Release);
            *shutdown_state
                .drain_deadline
                .lock()
                .expect("gateway drain lock poisoned") =
                Some(tokio::time::Instant::now() + shutdown_timeout);
            tracing::info!("gateway draining");
            let _ = draining_tx.send(());
        })
        .into_future();
    tokio::pin!(server);
    state.ready.store(true, Ordering::Release);
    let result = tokio::select! {
        result = &mut server => result,
        () = async {
            let _ = draining_rx.await;
            tokio::time::sleep(shutdown_timeout).await;
        } => Err(io::Error::new(io::ErrorKind::TimedOut, "gateway shutdown deadline exceeded")),
    };
    state.ready.store(false, Ordering::Release);
    result
}
