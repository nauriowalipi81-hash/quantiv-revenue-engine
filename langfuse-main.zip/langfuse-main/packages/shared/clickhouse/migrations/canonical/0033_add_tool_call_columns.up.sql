ALTER TABLE observations {CLICKHOUSE_CLUSTER_CLAUSE} ADD COLUMN IF NOT EXISTS tool_definitions Map(String, String) DEFAULT map() SETTINGS alter_sync = 2;
ALTER TABLE observations {CLICKHOUSE_CLUSTER_CLAUSE} ADD COLUMN IF NOT EXISTS tool_calls Array(String) DEFAULT [] SETTINGS alter_sync = 2;
ALTER TABLE observations {CLICKHOUSE_CLUSTER_CLAUSE} ADD COLUMN IF NOT EXISTS tool_call_names Array(String) DEFAULT [] SETTINGS alter_sync = 2;
