import { default as noTailwindOverflowScroll } from "./rules/no-tailwind-overflow-scroll.js";
import { default as filenameMatchesExport } from "./rules/filename-matches-export.js";
import { default as noArbitraryColors } from "./rules/no-arbitrary-colors.js";
import { default as noAbstractedOverlayTrigger } from "./rules/no-abstracted-overlay-trigger.js";
import { default as noInSourceVitest } from "./rules/no-in-source-vitest.js";
import { default as noExoticOperators } from "./rules/no-exotic-operators.js";
import { default as noMarginOnRootElements } from "./rules/no-margin-on-root-elements.js";
import { default as noNullRender } from "./rules/no-null-render.js";
import { default as noOverlayZindex } from "./rules/no-overlay-zindex.js";
import { default as noRawFontWeight } from "./rules/no-raw-font-weight.js";
import { default as requireTitleWithTruncate } from "./rules/require-title-with-truncate.js";
import { default as noStyleProps } from "./rules/no-style-props.js";
import { default as noSwitchStatements } from "./rules/no-switch-statements.js";
import { default as noUnnecessaryCn } from "./rules/no-unnecessary-cn.js";
import { default as storybookPlayRequiresTestName } from "./rules/storybook-play-requires-test-name.js";

const plugin = {
  rules: {
    "filename-matches-export": filenameMatchesExport,
    "no-abstracted-overlay-trigger": noAbstractedOverlayTrigger,
    "no-arbitrary-colors": noArbitraryColors,
    "no-exotic-operators": noExoticOperators,
    "no-in-source-vitest": noInSourceVitest,
    "no-margin-on-root-elements": noMarginOnRootElements,
    "no-null-render": noNullRender,
    "no-overlay-zindex": noOverlayZindex,
    "no-raw-font-weight": noRawFontWeight,
    "no-style-props": noStyleProps,
    "no-switch-statements": noSwitchStatements,
    "no-tailwind-overflow-scroll": noTailwindOverflowScroll,
    "no-unnecessary-cn": noUnnecessaryCn,
    "require-title-with-truncate": requireTitleWithTruncate,
    "storybook-play-requires-test-name": storybookPlayRequiresTestName,
  },
};

export default plugin;
